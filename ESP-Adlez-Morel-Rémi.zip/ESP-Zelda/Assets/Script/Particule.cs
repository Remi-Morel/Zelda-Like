using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Particule : MonoBehaviour
{
    Gestionnaire gestionnaire;


    private void Start()
    {
        gestionnaire = FindAnyObjectByType<Gestionnaire>();
    }


    void OnParticleCollision(GameObject other)
    { 
        if (other.gameObject.tag == "Joueur")
        {
            gestionnaire.Degat();
        }
    }




}
