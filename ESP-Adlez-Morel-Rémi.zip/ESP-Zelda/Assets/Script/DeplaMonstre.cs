using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeplaMonstre : MonoBehaviour
{
    int vitesse = 2;
    

    public float temps;
    public float tempsPasse;
    public float tempsTotal;
    public int Direction;

    Vector3 Deplacement;

    // Update is called once per frame
    void Update()
    {


        temps = Time.deltaTime;
        tempsPasse += temps;
        tempsTotal = Mathf.Round(tempsPasse);

        if (tempsTotal > 1)
        {
            if (Direction == 1 ) 
            {
                Deplacement = new Vector3(0, 1, 0) * vitesse * Time.deltaTime;
                transform.position += Deplacement;
                if (tempsTotal > 2)
                {
                    tempsPasse = 0;
                    tempsTotal = 0;
                }

            }
            if (Direction == 2)
            {
                Deplacement = new Vector3(1, 0, 0) * vitesse * Time.deltaTime;
                transform.position += Deplacement;
                if (tempsTotal > 2)
                {
                    tempsPasse = 0;
                    tempsTotal = 0;
                }
            }
            if (Direction == 3)
            {
                Deplacement = new Vector3(0, -1, 0) * vitesse * Time.deltaTime;
                transform.position += Deplacement;
                if (tempsTotal > 2)
                {
                    tempsPasse = 0;
                    tempsTotal = 0;
                }
            }
            if (Direction == 4)
            {
                Deplacement = new Vector3(-1, 0, 0) * vitesse * Time.deltaTime;
                transform.position += Deplacement;
                if (tempsTotal > 2)
                {
                    tempsPasse = 0;
                    tempsTotal = 0;
                }
            }
        }



        if (tempsTotal == 0)
        {
            Direction = Random.Range(1, 5);
        }




    }


}
