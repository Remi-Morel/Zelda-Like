using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;

public class Gestionnaire : MonoBehaviour
{
    private static Gestionnaire instance;
    public GameObject[] gameObjectsGrotte;
    public GameObject prefabVie;
    public GameObject Vie1;
    GameObject Vie;
    public Canvas canvas;
    public List<GameObject> listVie = new List<GameObject>();
    public DeplacementPerso Personnage;
    public GameObject prefabPerso;
    public GameObject Perso;
    public GameObject SpawnPoint;
    [SerializeField]
    GameObject ObjetQuete;
    [SerializeField]
    TextMeshProUGUI Fer;
    public int compteurFer;

    void Start()
    {
        for (int i = 1; i < 3; i++) 
        {
            Vie = Instantiate(prefabVie, new Vector3(Vie1.gameObject.transform.position.x+i*50, Vie1.gameObject.transform.position.y, 0), Quaternion.identity);
            listVie.Add(Vie);
            Vie.transform.SetParent(canvas.transform);
        }
    }

    private void Update()
    {
        if (Perso != null){}
        else
        {
            Perso = Instantiate(prefabPerso, SpawnPoint.transform.position, Quaternion.identity);
            Personnage = FindAnyObjectByType<DeplacementPerso>();
        }


    }
    void Awake()
    {
        if (instance != null)
        {
            Destroy(gameObject);
        }
        else
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
    }

    public void Degat()
    {
        if (listVie.Count > 1)
        {
            Destroy(listVie[listVie.Count-1]);
            listVie.RemoveAt(listVie.Count - 1);

        }
        else
        {
            Personnage.Mort();
        }
    }

    public void Regen()
    {
        if(listVie.Count < 3)
        {
            Vie = Instantiate(prefabVie, new Vector3(Vie1.gameObject.transform.position.x + listVie.Count * 50, Vie1.gameObject.transform.position.y, 0), Quaternion.identity); ;
            listVie.Add(Vie);
            Vie.transform.SetParent(canvas.transform);
        }
    }

    public void ChangeSpawn(Transform transform1)
    {
        SpawnPoint.transform.position = transform1.position;
    }

    public void VoirFer()
    {
        ObjetQuete.gameObject.SetActive(true);
    }

    public void CompteFer()
    {
        compteurFer++;
        if (compteurFer > 4)
        {
            compteurFer = 4;
        }
        Fer.SetText(string.Format("{0}", compteurFer));
    }
}
