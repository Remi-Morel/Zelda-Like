using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;
using UnityEngine.UI;

public class RecupeValeur : MonoBehaviour
{
    public GameObject CanvasBoss;
    public Image BarreVie;
    public GameObject SpawnBoss;
    public Tilemap MurBoss;



}
