using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class ScriptBoss : MonoBehaviour
{
    public DeplacementPerso ScriptPersonnage;

    bool calcTemps;
    float temps;
    public float tempsAttaque;
    public float tempsDegat;
    public float tempsPasse = 3f;
    public Animator animator;
    public float vie;
    public bool touche;
    public RecupeValeur RecupeValeur;
    private IEnumerator coroutine;

    public GameObject CanvasBoss;
    float maxhealth = 100;
    public Image BarreVie;

    public GameObject PrefabParticuleAttaque;
    GameObject ParticuleAttaque;

    public GameObject PrefabFer;
    GameObject Fer;

    Vector3 PosPerso;

    private void Start()
    {
        ScriptPersonnage = FindAnyObjectByType<DeplacementPerso>();
        RecupeValeur = FindAnyObjectByType<RecupeValeur>();
        RecupeValeur.CanvasBoss.gameObject.SetActive(true);
        calcTemps = true;
        vie = 100;

        coroutine = PosPersonnage(2.0f);
        StartCoroutine(coroutine);
    }

    private void Update()
    {
        temps = Time.deltaTime;
        tempsPasse += temps;
        if (tempsPasse > 3)
        {
            animator.SetBool("Attaque", true);
            tempsAttaque += temps;
            if(tempsAttaque > 1.5f)
            {
                animator.SetBool("Attaque", false);
                ParticuleAttaque = Instantiate(PrefabParticuleAttaque, transform.position, Quaternion.LookRotation(PosPerso - transform.position));
                Destroy(ParticuleAttaque,0.5f);
                tempsAttaque = 0f;
                tempsPasse = 0f;
            }
        }
        if (touche)
        {
            tempsDegat += temps;
            if(tempsDegat > 1f)
            {
                animator.SetBool("degat", false);
                touche = false;
                tempsDegat = 0f;
            }
        }

        if (vie < 1)
        {
            animator.SetBool("Mort", true);
            Destroy(gameObject, 2f);
            RecupeValeur.CanvasBoss.gameObject.SetActive(false);
            Fer = Instantiate(PrefabFer, transform.position, Quaternion.identity);
            RecupeValeur.MurBoss.gameObject.SetActive(false);
        }

        RecupeValeur.BarreVie.fillAmount = vie/maxhealth;

    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "�p�e")
        {
            vie -= 10;
            animator.SetBool("degat", true);
            touche = true;
        }
    }


    private IEnumerator PosPersonnage(float attente)
    {
        while (true)
        {
            PosPerso = ScriptPersonnage.transform.position;
            yield return new WaitForSeconds(attente);
        }
    }

}
