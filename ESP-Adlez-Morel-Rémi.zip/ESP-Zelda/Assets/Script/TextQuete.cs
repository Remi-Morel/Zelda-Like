using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class TextQuete : MonoBehaviour
{
    public Gestionnaire gestionnaire;

    [SerializeField]
    RawImage BordureImage;
    [SerializeField]
    TextMeshProUGUI textMeshProGUI;
    [SerializeField]
    TextMeshProUGUI EnleveTexte;
    [SerializeField]
    string TextQuete1;
    [SerializeField]
    string TextQuete2;
    [SerializeField]
    string Enleve;


    float temps;
    float tempsPasse;
    public float total;
    bool calcultemps = false;
    private void Start()
    {
        gestionnaire = FindAnyObjectByType<Gestionnaire>();
    }
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.F) && BordureImage.isActiveAndEnabled)
        {
            if (gestionnaire.compteurFer < 4)
            {
                textMeshProGUI.SetText(string.Format("{0}", TextQuete2));
                calcultemps = true;

                if (total > 2)
                {
                    BordureImage.gameObject.SetActive(false);
                    EnleveTexte.gameObject.SetActive(false);
                    gestionnaire.VoirFer();
                    tempsPasse = 0;
                    total = 0;
                    calcultemps = false;
                }
            }
            else
            {
                //Victoire//
            }
        }


        if (calcultemps)
        {
            temps = Time.deltaTime;
            tempsPasse += temps;
            total = Mathf.Round(tempsPasse);
        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        
        if (collision.gameObject.tag == "Joueur")
        {
            if (gestionnaire.compteurFer < 4)
            {
                EnleveTexte.gameObject.SetActive(true);
                EnleveTexte.SetText(string.Format("{0}", Enleve));
                BordureImage.gameObject.SetActive(true);
                textMeshProGUI.SetText(string.Format("{0}", TextQuete1));
            }
            else
            {
                EnleveTexte.gameObject.SetActive(true);
                EnleveTexte.SetText(string.Format("{0}", Enleve));
                BordureImage.gameObject.SetActive(true);
                textMeshProGUI.SetText(string.Format("{0}", "Merci grace a toi je vais pouvoir honorer mes commandes d'�p�es."));
            }
        }
    }
}
