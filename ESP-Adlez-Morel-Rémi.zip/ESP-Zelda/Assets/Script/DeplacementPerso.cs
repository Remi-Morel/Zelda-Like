using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Tilemaps;

public class DeplacementPerso : MonoBehaviour
{
    public RecupeValeur recupeValeur;
    public GameObject LastCheckpoint;

    public float Vitesse;
    private Vector2 input;

    public Gestionnaire gestionnaire;

    public float regard = 1;

    public GameObject SpawnBoss;
    public GameObject PrefabBoss;
    GameObject Boss;

    GameObject Epee;
    public GameObject EpeeGauche;
    public GameObject EpeeDroite;
    public GameObject EpeeHaut;
    public GameObject EpeeBas;
    bool isEpee = false;

    float temps;
    float tempsPasse;
    bool calcTemps = false;

    bool sceneForge = true;
    bool sceneMonde1 = false;
    bool sceneMonde2 = false;
    bool sceneGrotte = true;

    GameObject SpawnForge;
    GameObject SpawnGrotte;

    [SerializeField]
    Camera cameraPerso;

    [SerializeField]
    TextMeshProUGUI EnleveTexte;

    [SerializeField]
    Tilemap MurBoss;

    public Animator animator;
    private void Start()
    {
        gestionnaire = FindAnyObjectByType<Gestionnaire>();
    }
    void Update()
    {
        if (sceneForge)
        {
            if (SceneManager.GetActiveScene().name == "Forge")
            {
                SpawnForge = GameObject.Find("SpawnForge");
                transform.position = SpawnForge.transform.position;
                sceneForge = false;
                sceneMonde1 = true;
                sceneGrotte = true;
            }
        }
        if (sceneMonde1)
        {
            if (SceneManager.GetActiveScene().name == "MondeExterieur")
            {
                transform.position = gestionnaire.SpawnPoint.transform.position;
                sceneForge = true;
                sceneMonde1 = false;
                sceneGrotte = true;
            }
        }
        if (sceneMonde2)
        {
            if (SceneManager.GetActiveScene().name == "MondeExterieur")
            {
                transform.position = gestionnaire.SpawnPoint.transform.position;
                sceneForge = true;
                sceneMonde2 = false;
                sceneGrotte = true;
            }
        }
        if (sceneGrotte)
        {
            if (SceneManager.GetActiveScene().name == "Grotte")
            {
                SpawnGrotte = GameObject.Find("SpawnGrotte");
                recupeValeur = FindAnyObjectByType<RecupeValeur>();
                transform.position = SpawnGrotte.transform.position;
                sceneForge = true;
                sceneMonde2 = true;
                sceneGrotte = false;
                
            }
        }



        input.x = Input.GetAxis("Horizontal") * Vitesse * Time.deltaTime;
        input.y = Input.GetAxis("Vertical") * Vitesse * Time.deltaTime;

        if (input.x != 0) { input.y = 0; }


        if (input != Vector2.zero)
        {
            Vector3 depla = transform.position + new Vector3(input.x, input.y , 0);
            transform.position = depla;
            animator.SetBool("IsMoving", true);
        }
        else
        {
            animator.SetBool("IsMoving", false);
            animator.SetInteger("Direction", 0);
        }



        // Direction du regard pour attaque
        if (Mathf.Round(Input.GetAxis("Horizontal")+1) > 1)
        { 
            regard = 2; 
            animator.SetInteger("Direction", 2); 
        }
        if (Mathf.Round(Input.GetAxis("Horizontal")-1) < -1)
        { 
            regard = 4; 
            animator.SetInteger("Direction", 4); 
        }
        if (Mathf.Round(Input.GetAxis("Vertical")+1) > 1)
        { 
            regard = 1; 
            animator.SetInteger("Direction", 1); 
        }
        if (Mathf.Round(Input.GetAxis("Vertical")-1) < -1)
        { 
            regard = 3; 
            animator.SetInteger("Direction", 3);
        }



        //Attaque
        if (Input.GetKeyDown("space"))
        {
            if(isEpee == false)
            {
                if (regard == 1)
                {
                    Epee = Instantiate(EpeeHaut, transform.position + new Vector3(0, 0.75f, 0), Quaternion.identity);
                    Destroy(Epee, 0.25f);
                    isEpee = true;
                    calcTemps = true;

                }
                if (regard == 2)
                {
                    Epee = Instantiate(EpeeDroite, transform.position + new Vector3(0.75f, 0, 0), Quaternion.identity);
                    Destroy(Epee, 0.25f);
                    isEpee = true;
                    calcTemps = true;
                }
                if (regard == 3)
                {
                    Epee = Instantiate(EpeeBas, transform.position + new Vector3(0, -0.75f, 0), Quaternion.identity);
                    Destroy(Epee, 0.25f);
                    isEpee = true;
                    calcTemps = true;
                }
                if (regard == 4)
                {
                    Epee = Instantiate(EpeeGauche, transform.position + new Vector3(-0.75f, 0, 0), Quaternion.identity);
                    Destroy(Epee, 0.25f);
                    isEpee = true;
                    calcTemps = true;
                }
            }
        }
        if(calcTemps == true)
        {
            temps = Time.deltaTime;
            tempsPasse += temps;
            if(tempsPasse > 0.25)
            {
                isEpee = false;
                calcTemps = false;
                tempsPasse = 0;
            }
        }

    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Monstre")
        {
            gestionnaire.Degat();
        }
        if (collision.gameObject.tag == "Regen")
        {
            gestionnaire.Regen();
            Destroy(collision.gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Checkpoint")
        {
            LastCheckpoint = collision.gameObject;
        }
        if(collision.gameObject.tag == "Spawn")
        {
            gestionnaire.ChangeSpawn(collision.gameObject.transform);
        }
        if(collision.gameObject.tag == "Fer")
        {
            EnleveTexte.gameObject.SetActive(true);
            gestionnaire.CompteFer();
            Destroy(collision.gameObject);
        }
        if (collision.gameObject.tag == "Boss")
        {
            Boss = Instantiate(PrefabBoss, recupeValeur.SpawnBoss.transform.position, Quaternion.identity);
            recupeValeur.MurBoss.gameObject.SetActive(true);
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        EnleveTexte.gameObject.SetActive(false);

        if(collision.gameObject.tag == "Boss")
        {
            Destroy(Boss);
            recupeValeur.MurBoss.gameObject.SetActive(false);
            recupeValeur.CanvasBoss.gameObject.SetActive(false);
        }
    }

    public void Mort()
    {
        transform.position = LastCheckpoint.transform.position;
        gestionnaire.Regen();
        gestionnaire.Regen();
    }
}
