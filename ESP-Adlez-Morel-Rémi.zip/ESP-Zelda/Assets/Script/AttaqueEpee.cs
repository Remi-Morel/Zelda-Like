using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class AttaqueEpee : MonoBehaviour
{
    ScriptBoss ScriptBoss;
    private void Start()
    {
        ScriptBoss = FindAnyObjectByType<ScriptBoss>();
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Monstre")
        {
            Destroy(collision.gameObject);
        }
        if (collision.gameObject.tag == "Boss")
        {
            ScriptBoss.vie -= 2.5f;
            ScriptBoss.touche = true;
            ScriptBoss.animator.SetBool("degat", true);
        }
    }

}
